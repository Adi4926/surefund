import { Schema, models, model } from "mongoose";

export interface ICustomer {
  _id: string;
  fullName: string;
  mobile: string; // E.164, e.g. +91XXXXXXXXXX — unique login identifier
  email?: string;
  dob?: string;
  city?: string;
  pan?: string;
  isVerified: boolean;
  lastOtpSentAt?: Date;
  createdAt: Date;
  updatedAt: Date;
}

const CustomerSchema = new Schema<ICustomer>(
  {
    fullName: { type: String, required: true, trim: true },
    mobile: { type: String, required: true, unique: true, index: true },
    email: { type: String, lowercase: true, trim: true },
    dob: { type: String },
    city: { type: String },
    pan: { type: String, uppercase: true, trim: true },
    isVerified: { type: Boolean, default: false },
    lastOtpSentAt: { type: Date },
  },
  { timestamps: true }
);

export default models.Customer || model<ICustomer>("Customer", CustomerSchema);
