import Hero from "@/components/Hero";
import ProductCards from "@/components/ProductCards";
import TrustAndStats from "@/components/TrustAndStats";
import CibilCheckForm from "@/components/CibilCheckForm";

export default function HomePage() {
  return (
    <main>
      <Hero />
      <ProductCards />
      <TrustAndStats />
      <CibilCheckForm />
    </main>
  );
}
