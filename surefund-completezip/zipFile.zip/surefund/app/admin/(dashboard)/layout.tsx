import { requireAdmin } from "@/lib/requireAdmin";
import AdminShell from "@/components/admin/AdminShell";

export default function AdminDashboardLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const admin = requireAdmin(); // redirects to /admin/login if not authenticated

  return <AdminShell adminName={admin.email.split("@")[0]}>{children}</AdminShell>;
}
