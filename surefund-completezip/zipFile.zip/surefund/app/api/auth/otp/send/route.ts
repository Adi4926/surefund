import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { connectDB } from "@/lib/mongodb";
import Customer from "@/models/Customer";
import { sendOtp, toE164India } from "@/lib/otp";

const bodySchema = z.object({
  mobile: z.string().min(10, "Enter a valid mobile number"),
  fullName: z.string().min(2).optional(), // used on first-time signup
});

export async function POST(req: NextRequest) {
  try {
    const json = await req.json();
    const parsed = bodySchema.safeParse(json);
    if (!parsed.success) {
      return NextResponse.json(
        { error: parsed.error.issues[0].message },
        { status: 400 }
      );
    }

    const { mobile, fullName } = parsed.data;
    const e164 = toE164India(mobile);

    await connectDB();

    // Basic rate-limit: block resend within 30 seconds
    const existing = await Customer.findOne({ mobile: e164 });
    if (existing?.lastOtpSentAt) {
      const secondsSince = (Date.now() - existing.lastOtpSentAt.getTime()) / 1000;
      if (secondsSince < 30) {
        return NextResponse.json(
          { error: `Please wait ${Math.ceil(30 - secondsSince)}s before resending OTP` },
          { status: 429 }
        );
      }
    }

    await sendOtp(e164);

    await Customer.findOneAndUpdate(
      { mobile: e164 },
      {
        $set: { lastOtpSentAt: new Date() },
        $setOnInsert: { fullName: fullName || "SureFund Customer", mobile: e164 },
      },
      { upsert: true, new: true }
    );

    return NextResponse.json({ success: true, message: "OTP sent successfully" });
  } catch (err) {
    console.error("send OTP error:", err);
    return NextResponse.json({ error: "Failed to send OTP" }, { status: 500 });
  }
}
