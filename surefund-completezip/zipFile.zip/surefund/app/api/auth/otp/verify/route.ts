import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { connectDB } from "@/lib/mongodb";
import Customer from "@/models/Customer";
import { checkOtp, toE164India } from "@/lib/otp";
import { signToken } from "@/lib/auth";

const bodySchema = z.object({
  mobile: z.string().min(10),
  code: z.string().length(6, "OTP must be 6 digits"),
});

export async function POST(req: NextRequest) {
  try {
    const json = await req.json();
    const parsed = bodySchema.safeParse(json);
    if (!parsed.success) {
      return NextResponse.json(
        { error: parsed.error.issues[0].message },
        { status: 400 }
      );
    }

    const { mobile, code } = parsed.data;
    const e164 = toE164India(mobile);

    const { approved } = await checkOtp(e164, code);
    if (!approved) {
      return NextResponse.json({ error: "Invalid or expired OTP" }, { status: 401 });
    }

    await connectDB();
    const customer = await Customer.findOneAndUpdate(
      { mobile: e164 },
      { $set: { isVerified: true } },
      { new: true, upsert: true }
    );

    const token = signToken({
      type: "customer",
      id: String(customer._id),
      mobile: customer.mobile,
    });

    const res = NextResponse.json({
      success: true,
      customer: {
        id: customer._id,
        fullName: customer.fullName,
        mobile: customer.mobile,
      },
    });

    res.cookies.set("surefund_token", token, {
      httpOnly: true,
      secure: true,
      sameSite: "lax",
      path: "/",
      maxAge: 60 * 60 * 24 * 7, // 7 days
    });

    return res;
  } catch (err) {
    console.error("verify OTP error:", err);
    return NextResponse.json({ error: "Failed to verify OTP" }, { status: 500 });
  }
}
