"use client";

import { motion } from "framer-motion";

const partners = [
  "HDFC Bank",
  "ICICI Bank",
  "Axis Bank",
  "SBI",
  "Kotak Mahindra",
  "IDFC First",
  "IndusInd Bank",
  "Bajaj Finserv",
  "Tata Capital",
];

const stats = [
  { value: "₹100+ Cr", label: "Loans Facilitated" },
  { value: "5000+", label: "Happy Customers" },
  { value: "25+", label: "Banking Partners" },
  { value: "98%", label: "Customer Satisfaction" },
];

export default function TrustAndStats() {
  const loopPartners = [...partners, ...partners];

  return (
    <>
      <section className="border-y border-primary/5 bg-white py-12">
        <p className="mb-8 text-center text-sm font-medium uppercase tracking-wide text-primary/40">
          Trusted Banking &amp; NBFC Partners
        </p>
        <div className="relative overflow-hidden">
          <div className="flex w-max animate-marquee gap-16">
            {loopPartners.map((name, i) => (
              <span
                key={`${name}-${i}`}
                className="whitespace-nowrap text-xl font-heading font-semibold text-primary/30"
              >
                {name}
              </span>
            ))}
          </div>
        </div>
      </section>

      <section className="bg-gradient-hero py-16 text-white">
        <div className="section !py-0 grid grid-cols-2 gap-8 md:grid-cols-4">
          {stats.map((s, i) => (
            <motion.div
              key={s.label}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: i * 0.1 }}
              className="text-center"
            >
              <div className="text-3xl font-bold text-accent md:text-4xl">
                {s.value}
              </div>
              <div className="mt-1 text-sm text-white/70">{s.label}</div>
            </motion.div>
          ))}
        </div>
      </section>
    </>
  );
}
