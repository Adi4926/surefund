"use client";

import { useState } from "react";
import Link from "next/link";
import { Menu, X, Phone } from "lucide-react";

const links = [
  { label: "Home", href: "/" },
  { label: "About Us", href: "/about" },
  { label: "Personal Loan", href: "/personal-loan" },
  { label: "Business Loan", href: "/business-loan" },
  { label: "Credit Card", href: "/credit-card" },
  { label: "EMI Calculator", href: "/emi-calculator" },
  { label: "Blog", href: "/blog" },
  { label: "Contact", href: "/contact" },
];

export default function Navbar() {
  const [open, setOpen] = useState(false);

  return (
    <header className="sticky top-0 z-50 border-b border-primary/5 bg-white/80 backdrop-blur-lg">
      <div className="mx-auto flex max-w-7xl items-center justify-between px-6 py-4">
        <Link href="/" className="font-heading text-xl font-bold text-primary">
          Sure<span className="text-secondary">Fund</span>
        </Link>

        <nav className="hidden items-center gap-6 lg:flex">
          {links.map((link) => (
            <Link
              key={link.href}
              href={link.href}
              className="text-sm font-medium text-primary/70 transition-colors hover:text-secondary"
            >
              {link.label}
            </Link>
          ))}
        </nav>

        <div className="hidden items-center gap-3 lg:flex">
          <a
            href="tel:+911234567890"
            className="flex items-center gap-1.5 text-sm font-medium text-primary/70"
          >
            <Phone size={16} /> +91 1234567890
          </a>
          <Link href="/personal-loan" className="btn-primary !px-5 !py-2.5 text-sm">
            Apply Now
          </Link>
        </div>

        <button className="text-primary lg:hidden" onClick={() => setOpen(true)}>
          <Menu size={26} />
        </button>
      </div>

      {open && (
        <div className="fixed inset-0 z-50 bg-primary text-white lg:hidden">
          <div className="flex items-center justify-between px-6 py-4">
            <span className="font-heading text-xl font-bold">SureFund</span>
            <button onClick={() => setOpen(false)}>
              <X size={26} />
            </button>
          </div>
          <nav className="flex flex-col gap-1 px-6 py-4">
            {links.map((link) => (
              <Link
                key={link.href}
                href={link.href}
                onClick={() => setOpen(false)}
                className="rounded-lg px-3 py-3 text-lg font-medium text-white/80 hover:bg-white/10 hover:text-white"
              >
                {link.label}
              </Link>
            ))}
            <Link
              href="/personal-loan"
              onClick={() => setOpen(false)}
              className="btn-accent mt-4 w-full"
            >
              Apply Now
            </Link>
          </nav>
        </div>
      )}
    </header>
  );
}
