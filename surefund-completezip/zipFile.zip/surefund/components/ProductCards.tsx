"use client";

import { motion } from "framer-motion";
import { Wallet, Briefcase, CreditCard, ShieldCheck, ArrowRight } from "lucide-react";

const products = [
  {
    title: "Personal Loan",
    desc: "Up to ₹25 Lakh for weddings, medical needs, travel & more.",
    icon: Wallet,
    href: "/personal-loan",
    gradient: "from-secondary to-blue-400",
  },
  {
    title: "Business Loan",
    desc: "Fuel your growth with collateral-free working capital.",
    icon: Briefcase,
    href: "/business-loan",
    gradient: "from-primary to-secondary",
  },
  {
    title: "Credit Card",
    desc: "Premium cards with cashback, rewards & lounge access.",
    icon: CreditCard,
    href: "/credit-card",
    gradient: "from-accent to-amber-500",
  },
  {
    title: "Free CIBIL Check",
    desc: "Know your credit score instantly — 100% free, no impact.",
    icon: ShieldCheck,
    href: "/cibil-check",
    gradient: "from-emerald-500 to-teal-400",
  },
];

export default function ProductCards() {
  return (
    <section className="section">
      <div className="mx-auto mb-14 max-w-2xl text-center">
        <h2 className="text-3xl font-bold text-primary md:text-4xl">
          Products Tailored For You
        </h2>
        <p className="mt-3 text-primary/60">
          Choose a product below and apply in minutes.
        </p>
      </div>

      <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-4">
        {products.map((p, i) => (
          <motion.a
            key={p.title}
            href={p.href}
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: i * 0.1 }}
            whileHover={{ scale: 1.04, y: -6 }}
            className="glass-card group relative block overflow-hidden p-6 transition-shadow hover:shadow-glow"
          >
            <div
              className={`mb-5 flex h-14 w-14 items-center justify-center rounded-xl bg-gradient-to-br ${p.gradient} text-white shadow-md transition-transform group-hover:scale-110`}
            >
              <p.icon size={26} />
            </div>
            <h3 className="text-lg font-semibold text-primary">{p.title}</h3>
            <p className="mt-2 text-sm text-primary/60">{p.desc}</p>
            <div className="mt-5 flex items-center gap-1 text-sm font-medium text-secondary opacity-0 transition-opacity group-hover:opacity-100">
              Apply Now <ArrowRight size={16} />
            </div>
          </motion.a>
        ))}
      </div>
    </section>
  );
}
