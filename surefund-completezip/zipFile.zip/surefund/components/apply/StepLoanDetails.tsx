"use client";

import { ApplyDraft } from "@/lib/applyFormStorage";
import { ProductType } from "@/lib/constants";

export default function StepLoanDetails({
  data,
  onChange,
  productType,
}: {
  data: ApplyDraft;
  onChange: (patch: Partial<ApplyDraft>) => void;
  productType: ProductType;
}) {
  const isCreditCard = productType === "Credit Card";

  return (
    <div className="space-y-4">
      <h2 className="text-xl font-bold text-primary">
        {isCreditCard ? "Credit Card Details" : "Loan Details"}
      </h2>
      <p className="text-sm text-primary/50">
        {isCreditCard
          ? "Tell us how much credit limit you're looking for."
          : "Tell us how much you'd like to borrow."}
      </p>

      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
        <input
          required
          type="number"
          min={0}
          placeholder={isCreditCard ? "Desired Credit Limit (₹)" : "Loan Amount Required (₹)"}
          value={data.loanAmount}
          onChange={(e) => onChange({ loanAmount: e.target.value })}
          className="rounded-lg border border-primary/10 px-4 py-3 outline-none focus:border-secondary sm:col-span-2"
        />
        <input
          type="number"
          min={300}
          max={900}
          placeholder="CIBIL Score (if known)"
          value={data.cibilScore}
          onChange={(e) => onChange({ cibilScore: e.target.value })}
          className="rounded-lg border border-primary/10 px-4 py-3 outline-none focus:border-secondary"
        />
        <input
          type="number"
          min={0}
          placeholder="Existing Monthly EMI (₹)"
          value={data.existingEmi}
          onChange={(e) => onChange({ existingEmi: e.target.value })}
          className="rounded-lg border border-primary/10 px-4 py-3 outline-none focus:border-secondary"
        />
      </div>

      <label className="flex items-center gap-2 text-sm text-primary/70">
        <input
          type="checkbox"
          checked={data.existingLoan}
          onChange={(e) => onChange({ existingLoan: e.target.checked })}
        />
        I currently have an existing loan or credit obligation
      </label>
    </div>
  );
}
