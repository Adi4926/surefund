"use client";

import { motion } from "framer-motion";

export default function Hero() {
  return (
    <section className="relative overflow-hidden bg-gradient-hero text-white">
      {/* decorative glow orbs */}
      <div className="pointer-events-none absolute -left-24 -top-24 h-96 w-96 rounded-full bg-secondary/30 blur-3xl" />
      <div className="pointer-events-none absolute -right-24 top-40 h-96 w-96 rounded-full bg-accent/20 blur-3xl" />

      <div className="section relative z-10 flex flex-col items-center text-center">
        <motion.span
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="glass-dark mb-6 rounded-full px-4 py-1.5 text-sm font-medium text-accent"
        >
          Funding Dreams. Building Futures.
        </motion.span>

        <motion.h1
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.1 }}
          className="max-w-4xl text-4xl font-bold leading-tight md:text-6xl"
        >
          Get the Right Loan with{" "}
          <span className="text-accent">Expert Guidance</span>
        </motion.h1>

        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.2 }}
          className="mt-6 max-w-2xl text-lg text-white/80"
        >
          Personal Loans, Business Loans &amp; Credit Cards with fast
          processing and trusted assistance — backed by SureFund Financial
          Services, Lucknow.
        </motion.p>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.3 }}
          className="mt-10 flex flex-wrap items-center justify-center gap-4"
        >
          <a href="/personal-loan" className="btn-accent">
            Apply Now
          </a>
          <a href="/cibil-check" className="btn-outline">
            Check Eligibility
          </a>
        </motion.div>
      </div>
    </section>
  );
}
